#!/bin/bash

# Handle error =============================================
abort() {
    errcode=$?
    echo "
≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡
Error!
Command: $BASH_COMMAND
Line: ${BASH_LINENO[0]}
≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡
Aborting installation..."
    exit $errcode
}
trap abort ERR


# sudo check ===============================================
if ! [ "$EUID" -ne 0 ] ; then
    echo "Run in non-sudo mode!"
    echo "Aborting installation..."
    exit
fi


# vars  ====================================================
result=1
as_installer=0
app_paths=(
    "$HOME/.Nozbe"
    "$HOME/.config/Nozbe"
    "$HOME/.local/share/applications/Nozbe.desktop"
    )
case "$1" in
 "-i") run_from_installer=1 ;;
 *) run_from_installer=0 ;;
esac
case "$run_from_installer" in
 1) script_name="installer" ;;
 0) script_name="uninstaller" ;;
esac

#begin =====================================================

# check if run from installer
for path in "${app_paths[@]}" ; do
    echo -n " * Removing '$path'"
    # try to remove files if exists
    touch $path && rm -rf $path &> /dev/null && echo " ✔" || {
        echo -e " - You don't have permission to remove '$path' or some of its subdirectories."
        result=0
    }
done

if [ $result == 1 ] ; then
  if [ $run_from_installer == 0 ] ; then
    echo "Nozbe has been uninstalled successfully!"
  fi
else
    echo -e "Some files couldn't be removed. Make sure you have full permissions to them and re-run $script_name."
    # if run from istaller exit with error
    if [ $run_from_installer == 1 ] ; then
        echo "Aborting installation..."
        exit 1
    fi
fi
