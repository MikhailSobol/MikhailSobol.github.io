To install Nozbe <%- version %> on Linux just follow these steps:

* If you have Nozbe version older than 3.0.2, uninstall it
* Open terminal and go to the folder containing downloader.sh
* Run downloader.sh directly or by typing `bash downloader.sh` and follow
  installation steps
* Nozbe app is installed in `~/.Nozbe`
