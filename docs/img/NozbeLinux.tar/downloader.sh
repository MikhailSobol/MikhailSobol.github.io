#!/bin/bash

# handle error =============================================
abort() {
    errcode=$?
    echo "
≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡
Error!
Command: $BASH_COMMAND
Line: ${BASH_LINENO[0]}
≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡
Aborting installation...
"
    exit $errcode
}
trap abort ERR


# don't run with sudo ======================================
if ! [ "$EUID" -ne 0 ] ; then
    echo "Run in non-sudo mode!"
    echo "Aborting installation..."
    exit
fi

# pause ====================================================
pause(){
   read -p "$*"
}

# download =================================================
download(){
    local url=$1
    local destination=$2
    wget --progress=dot -O $destination $url 2>&1 | grep --line-buffered -o "[0-9]*%" | \
        xargs -L1 echo -en "\b\b\b\b"
    echo " ✔"
}


# BEGIN =================================================
version=3.5.2

# get current architecture
if [ $(uname -m) == "x86_64" ]; then
    archPrefix="x"
    arch="64"
    # name of downloaded folder in /tmp
    tmpDirName=Nozbe-$version
else
    archPrefix="ia"
    arch="32"
    tmpDirName=Nozbe-$version-$archPrefix$arch
fi

# current dir
curDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# variables
url="https://files.nozbe.com/linux/linux${arch}_newest.tar.gz"

destination="/tmp/nozbe.tar.gz"

# disclaimer
clear
echo "
                      ,%@@@@@@@@@@@@*
                 %@@@@@@@@@@@@@@@@@@@@@@@@,
             *@@@@@@@@@@@@@@@@@@@@@@@@@@@@%     **,
           @@@@@@@@@@@@(           ,&@@@@     .******
        .@@@@@@@@@(                          *********,
       @@@@@@@@*                           ,************
     #@@@@@@@                             **************
    @@@@@@@.                            ,*************,
   @@@@@@@                             **************
  @@@@@@&                            ,*************     .
 /@@@@@@                            *************      @@@
 @@@@@@                           ,************.     @@@@@*
,@@@@@%                          *************       @@@@@@
&@@@@@          .**.           *************         @@@@@@
@@@@@@         ******.        ************           &@@@@@
@@@@@@        *********.    ************.            @@@@@@
%@@@@@.        **********. ***********,              @@@@@@
.@@@@@&          ********************               .@@@@@&
 @@@@@@.           ****************                 @@@@@@
 .@@@@@@             ************                  %@@@@@@
  #@@@@@@              ********,                  #@@@@@@
   %@@@@@@               *****                   @@@@@@@
    (@@@@@@&               *                   .@@@@@@@
      @@@@@@@%                               .@@@@@@@%
       %@@@@@@@@.                          %@@@@@@@@
         &@@@@@@@@@/                   .@@@@@@@@@@
           /@@@@@@@@@@@@@#,.   .,/&@@@@@@@@@@@@&
              (@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                  #@@@@@@@@@@@@@@@@@@@@@&.


Nozbe ${version} (${arch}bit) will be downloaded and installed in:
$HOME/.Nozbe
$HOME/.config/
$HOME/.local/share/applications

If there is a previous version, it will be closed and removed now.

"
echo "Terms of Service: https://nozbe.com/terms/"
pause "If you agree with our Terms of Service press [Return] key..."
echo "≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡"

# quit Nozbe if opened
killall Nozbe &> /dev/null || :

# run uninstaller and exit on error
bash $curDir/uninstaller.sh -i || exit

# download
echo "Downloading..."
download $url $destination

# extract archive
echo "Extracting the archive..."
chown $(id -u) $destination &> /dev/null
chmod 0755 $destination &> /dev/null
tar -xf $destination -C /tmp --overwrite --preserve-permissions &> /dev/null || {
  echo "Error extracting the archive!"
  echo "Aborting installation..."
  exit
}

# run installer
echo "Installing..."
bash /tmp/$tmpDirName/installer.sh

# remove files from /tmp
rm -rf /tmp/$tmpDirName/ $destination
echo "Temporary files have been removed."
